<div class="ttl">
    Harga Bitcoin Hari Ini
</div>

<table class="tbl" id="infoBTC">
    <thead>
    <tr>
        <th>Mata Uang</th>
        <th>Harga Beli</th>
        <th>Harga Jual</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td colspan="3">&nbsp;</td>
    </tr>
    </tbody>
</table>