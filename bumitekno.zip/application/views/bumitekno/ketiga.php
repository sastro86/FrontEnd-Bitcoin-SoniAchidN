<div class="ttl">
    Konversi Bitcoin ke Rupiah
    <div><small>Kurs 1 USD = 14.000 IDR</small></div>
    <div><small id="hariiniUSD"></small></div>
</div>

<div class="ttl" id="konversiRP">
    <input type="number" value="" min="1" id="check"/>
</div>

<div class="ttl">
    <table class="tbl center">
        <thead>
        <tr>
            <th>BTC</th>
            <th>to</th>
            <th>Value</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td><span id="key">0</span></td>
            <td><span id="sym">USD</span></td>
            <td><span id="value">0</span></td>
        </tr>
        <tr>
            <td><span id="key_1"></span></td>
            <td><span id="sym_1">IDR</span></td>
            <td><span id="value_1">0</span></td>
        </tr>
        </tbody>
    </table>
</div>
